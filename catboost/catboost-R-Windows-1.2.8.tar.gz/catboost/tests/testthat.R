library(testthat)
library(catboost)

test_check("catboost")
